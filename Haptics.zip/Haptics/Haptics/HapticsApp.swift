//
//  HapticsApp.swift
//  Haptics
//
//  Created by Ahmya Rivera on 9/30/25.
//

import SwiftUI

@main
struct HapticsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
